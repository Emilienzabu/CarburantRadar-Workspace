# Mesure de performance

## Indicateurs vidéo
- rétention à 1 s, 3 s et fin de vidéo ;
- durée moyenne de visionnage ;
- taux de complétion ;
- partages, enregistrements et commentaires ;
- clics vers le site ;
- utilisateurs nouveaux attribuables à la vidéo.

## Indicateurs produit
- sessions qualifiées ;
- recherches effectuées ;
- stations consultées ;
- activation des favoris/alertes ;
- rétention à 7 et 30 jours.

Les vues seules ne suffisent pas à conclure qu'une vidéo acquiert des utilisateurs.
