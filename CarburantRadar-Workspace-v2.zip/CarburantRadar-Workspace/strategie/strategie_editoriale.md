# Stratégie éditoriale

## Piliers de contenu
- prix locaux réellement vérifiés ;
- comparaisons de stations ;
- démonstrations de l'application ;
- conseils pratiques pour éviter les détours inutiles ;
- explications sur les carburants et les données ;
- nouveautés produit.

## Règles
- Toujours dater les données.
- Afficher le pays, la ville et le carburant.
- Éviter les accroches sensationnalistes non étayées.
- Ne pas confondre prix le plus bas et économie nette après détour.
- Adapter le format à la plateforme.
