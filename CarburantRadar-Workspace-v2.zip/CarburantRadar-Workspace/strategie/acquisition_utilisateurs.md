# Acquisition utilisateurs

## Objectif principal
Acquérir de nouveaux utilisateurs actifs pour CarburantRadar, pas seulement maximiser les vues.

## Canaux à étudier
- vidéos courtes démontrant une économie ou un usage concret ;
- référencement naturel local et pages réellement utiles ;
- partage entre proches et communautés automobiles ;
- partenariats locaux transparents ;
- QR codes sur supports autorisés ;
- recommandations et favoris partageables.

## Mesure
Suivre, lorsque les données sont disponibles : visites qualifiées, inscriptions, première recherche, retour à 7/30 jours, activation des alertes et utilisateurs récurrents.

Ne jamais inventer un coût d'acquisition ni une conversion.
