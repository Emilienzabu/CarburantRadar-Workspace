# Audit sécurité et confidentialité

## Périmètre prioritaire
- mots de passe et hachage côté serveur ;
- routes d'inscription, connexion et synchronisation ;
- émission, expiration, stockage et révocation des tokens ;
- contrôle d'accès par compte ;
- limitation de débit et protection contre les abus ;
- données collectées et durée de conservation ;
- suppression des données et des comptes ;
- logs, analytics et identifiants persistants.

## État
`BLOQUÉ PARTIELLEMENT` : le code complet du Worker proxy carburant est nécessaire pour vérifier les mécanismes serveur.

## Précaution
Ne transmettre que le code source expurgé. Ne jamais communiquer les valeurs des variables secrètes.
