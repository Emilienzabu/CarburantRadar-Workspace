# Audit vidéos

## Objectif
Améliorer la qualité visuelle, la qualité éditoriale, la rétention, la viralité et surtout l'acquisition de nouveaux utilisateurs CarburantRadar.

## Constats historiques à revalider
- Des dates de prix pouvaient être considérées récentes avec une fenêtre proche de six jours.
- Un texte de rendu annonçait une mise à jour « aujourd'hui » sans vérification systématique.
- Une limite de résultats API pouvait créer un biais d'échantillonnage.
- Les classements et statistiques de villes pouvaient ne représenter qu'une zone autour du centre.
- Les formats étaient sélectionnés de façon déterministe avec des pondérations théoriques Ville 50 %, Classement 30 %, Astuce 20 %.
- La génération produisait du 1080×1920, 30 fps, H.264/AAC, avec voix TTS, musique procédurale et FFmpeg.

## Priorités permanentes
1. Véracité et fraîcheur des prix.
2. Accroche claire dans les premières secondes.
3. Différenciation visuelle des formats.
4. Démonstration concrète de l'application.
5. Sous-titres lisibles et zones de sécurité mobile.
6. Voix naturelle et prononciation correcte.
7. Appel à l'action utile, sans promesse trompeuse.
8. Mesure des utilisateurs acquis, pas seulement des vues.

Aucune performance vidéo ne doit être affirmée sans données analytics.
