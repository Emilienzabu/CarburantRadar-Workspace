# Audits

Chaque audit doit inclure : périmètre, version examinée, méthode, constats, preuves, niveau de confiance, impact, priorité et recommandations. Ne pas présenter une hypothèse comme une vulnérabilité confirmée.
