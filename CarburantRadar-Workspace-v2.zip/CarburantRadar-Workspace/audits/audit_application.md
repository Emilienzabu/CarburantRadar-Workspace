# Audit application

## Constats historiques à revalider
- Des clés LocalStorage sont partagées entre pages/pays ; vérifier les collisions d'identifiants et la séparation des préférences.
- Vérifier la fusion des données locales et serveur lors de la connexion/synchronisation.
- Vérifier la désinscription aux notifications lorsque l'appel serveur échoue.
- Vérifier l'affichage de la date de mise à jour par station.
- Vérifier le traitement des horaires inconnus : ne pas assimiler automatiquement « inconnu » à « ouvert ».
- Vérifier la distinction entre temps d'itinéraire calculé et temps estimé.
- Vérifier que les économies tiennent compte du détour et du carburant réellement nécessaire.
- Vérifier la validation des coordonnées et des prix.

## International
Un audit antérieur a relevé des indices de paramètres de géocodage français et de requêtes d'historique françaises utilisés dans des parcours Espagne/Italie. À recontrôler dans la version actuelle.

## Confidentialité
La politique de confidentialité doit correspondre aux flux réels : compte, synchronisation, alertes, analytics et suivi d'usage.
