# Audit international

## Pays couverts
France, Espagne, Italie.

## Vérifications à mener
- source de données officielle ou fiable par pays ;
- noms et correspondances des carburants ;
- devise, format décimal et unités ;
- fuseaux horaires et dates locales ;
- disponibilité et fraîcheur des prix ;
- géocodage limité au pays concerné ;
- itinéraires et navigation ;
- historique et comparaisons adaptés à chaque source ;
- traductions et mentions légales locales.

Ne pas supposer que le schéma de données français s'applique à l'Espagne ou à l'Italie.
