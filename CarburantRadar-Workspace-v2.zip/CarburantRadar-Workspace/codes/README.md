# Sources de code

Archiver ici des copies lisibles des sources utiles à l'analyse. Ajouter pour chaque fichier : chemin d'origine, branche/commit, date de copie et statut de vérification. Retirer les secrets avant tout ajout.
