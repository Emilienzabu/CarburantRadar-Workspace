# GitHub Actions

## Informations historiques
Un workflow `Vidéo du jour` a été décrit avec deux déclenchements quotidiens, vers 06:40 et 16:40 UTC, et des options de génération/publication.

Ces paramètres sont `À CONFIRMER` dans la branche active.

## Vérifications
- cron et fuseau horaire ;
- permissions du `GITHUB_TOKEN` ;
- secrets utilisés ;
- concurrence et annulation ;
- durée maximale ;
- conservation des artefacts ;
- comportement en cas d'échec ;
- distinction génération / publication.
