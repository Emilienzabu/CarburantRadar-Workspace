# Worker proxy carburant

## État
`À CONFIRMER` — le code source complet n'est pas encore archivé ici.

URL connue : https://carburant-proxy.emilienzabukovec09.workers.dev

## Points à auditer
- routes publiques et privées ;
- authentification et autorisations ;
- validation des paramètres ;
- cache et fraîcheur des données ;
- limitation de débit ;
- gestion des erreurs ;
- inscription, connexion et synchronisation ;
- création, expiration et révocation des tokens ;
- collecte, conservation et suppression des données ;
- séparation des données entre comptes.

Ne pas inclure de valeurs de secrets dans ce fichier.
