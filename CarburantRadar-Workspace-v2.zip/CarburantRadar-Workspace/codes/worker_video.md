# Worker automatisation vidéo

## État
`À CONFIRMER` — les extraits précédemment communiqués doivent être comparés à la version déployée.

Nom/URL connus : `video-automation.emilienzabukovec09.workers.dev`.

## Points à auditer
- authentification de l'interface ;
- séparation des profils ;
- gestion des tokens YouTube et Instagram ;
- idempotence des publications ;
- traitement des échecs partiels ;
- suppression ou conservation des médias ;
- accès public aux fichiers ;
- validation des vidéos avant publication ;
- journalisation et alertes.

Les tokens et secrets ne doivent jamais être archivés ici.
