# Cellules Python

## Inventaire
Aucune cellule complète n'est encore archivée dans ce Workspace.

Pour chaque cellule ajoutée, préciser :
- objectif ;
- environnement ;
- dépendances ;
- entrées et sorties ;
- effets éventuels ;
- date et version ;
- statut de validation.

Ne jamais exécuter une cellule qui écrit dans le dépôt ou publie du contenu sans autorisation explicite.
