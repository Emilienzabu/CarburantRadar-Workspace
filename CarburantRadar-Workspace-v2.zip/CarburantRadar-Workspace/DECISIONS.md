# Décisions

Ne consigner ici que les décisions explicitement acceptées.

## Décisions établies
- Le dépôt Workspace doit être distinct du dépôt de production.
- Le dépôt Workspace doit être privé par défaut.
- Les audits du projet sont en lecture seule tant qu'une modification n'est pas explicitement demandée.
- Ne pas baser la monétisation sur AdSense tant que le site n'est pas accepté et que l'utilisateur ne souhaite pas cette voie.

## À décider
- Méthode définitive de synchronisation entre ChatGPT et Claude.
- Organisation des fichiers sources et fréquence des mises à jour.
- Politique de conservation des journaux d'audit.
