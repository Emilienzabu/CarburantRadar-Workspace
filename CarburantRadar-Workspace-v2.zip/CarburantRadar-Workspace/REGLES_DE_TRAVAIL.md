# Règles de travail

1. Lire le contexte, l'avancement, les décisions et les règles de sécurité avant de commencer.
2. Distinguer faits vérifiés, déclarations du propriétaire, hypothèses et propositions.
3. Ne jamais transformer une proposition en décision sans acceptation explicite.
4. Ne pas modifier le dépôt de production, pousser de commit, déployer, déclencher un workflow ou publier sans demande explicite.
5. Ne jamais modifier les secrets Cloudflare, tokens OAuth ou identifiants.
6. Ne jamais engager de dépense ou activer un service payant sans accord explicite.
7. Ne pas interrompre un audit simplement pour demander une validation intermédiaire, sauf blocage réel ou décision irréversible.
8. Documenter les limites et les éléments qui restent à vérifier.
9. En fin de session, mettre à jour `AVANCEMENT.md`, `CHANGELOG.md` et le journal daté.
10. Ne pas annoncer qu'un partage est opérationnel avant d'avoir testé les accès des deux assistants.
