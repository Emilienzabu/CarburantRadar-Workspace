# Inventaire technique

## Application
- PWA mobile.
- Pays : France, Espagne, Italie.
- Géolocalisation et rayons de recherche mentionnés : 5, 10, 20 et 50 km.
- Favoris, noms personnalisés, repères Domicile/Travail, alertes de prix, itinéraires et estimations de coût.
- Stockage local : clés connues notamment `cr_favs`, `cr_names`, `cr_reps`, `cr_alert_key`, `cr_alert_info`.

## Services externes connus
- Données françaises : data.economie.gouv.fr.
- Proxy : Worker Cloudflare `carburant-proxy`.
- Itinéraires : OSRM.
- Cartographie : Leaflet / OpenStreetMap (à confirmer dans le code actuel).
- Analytics : GA4 `G-VNKWD96SLL`.

## Automatisation vidéo
- Dépôt de production : même dépôt CarburantRadar.
- Dossiers connus : `generator/` et `video/`.
- Worker vidéo : `video-automation.emilienzabukovec09.workers.dev`.
- Publication YouTube / Instagram mentionnée dans le code fourni antérieurement.

## À vérifier
- Arborescence actuelle de la branche `main`.
- Versions effectivement déployées.
- Configuration des workflows.
- Correspondance entre code local, GitHub et Workers Cloudflare.
