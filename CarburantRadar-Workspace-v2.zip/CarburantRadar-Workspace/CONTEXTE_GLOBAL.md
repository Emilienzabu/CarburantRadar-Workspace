# Contexte global

## Projet
CarburantRadar est une application web progressive (PWA) de comparaison des prix des carburants, avec une couverture annoncée en France, Espagne et Italie.

- Dépôt de production : https://github.com/Emilienzabu/CarburantRadar
- GitHub Pages : https://emilienzabu.github.io/CarburantRadar/
- Domaine également utilisé/évoqué : https://carburantradar.fr/
- Signature de développement : Zabukovec Company

## Objectif
Aider les automobilistes à comparer les prix, trouver des stations et estimer les économies, avec une expérience mobile claire.

## Principes
- Exactitude des données avant la quantité de fonctionnalités.
- Ne jamais présenter une estimation comme une mesure réelle.
- Ne pas inventer de statistiques de performance ou d'acquisition.
- Pas de stratégie reposant sur AdSense : le site n'a pas été accepté par AdSense et aucune publicité n'est actuellement diffusée selon le propriétaire.
- Priorité à l'acquisition d'utilisateurs réellement actifs.

## Couverture et carburants
France : Gazole, SP95, SP98, E10, E85, GPLc.
Espagne : GasoleoA, GasoleoPremium, Gasolina95, Gasolina98, GLP.
Italie : benzina, gasolio, GPL, metano.

## Infrastructure connue (à revalider)
- Source française : data.economie.gouv.fr
- Proxy carburant : https://carburant-proxy.emilienzabukovec09.workers.dev
- Routage : OSRM, `router.project-osrm.org`
- Analytics : GA4 `G-VNKWD96SLL`

Ne jamais considérer ces informations comme une preuve que les services sont actuellement opérationnels.
