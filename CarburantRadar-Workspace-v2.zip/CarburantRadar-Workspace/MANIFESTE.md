# Manifeste du Workspace

Ce dépôt est la mémoire documentaire de travail de CarburantRadar.

Il doit permettre à plusieurs assistants et contributeurs de retrouver :
- le contexte du produit ;
- les décisions réellement prises ;
- les audits et leurs preuves ;
- les sources techniques partagées ;
- les idées en attente ;
- l'avancement et les prochaines étapes.

Le dépôt ne remplace ni le dépôt de production ni les outils de déploiement. Il ne doit contenir aucun secret.
