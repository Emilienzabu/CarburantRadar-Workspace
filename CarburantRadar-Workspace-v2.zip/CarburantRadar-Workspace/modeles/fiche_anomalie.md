# Anomalie — Titre

- Statut : À CONFIRMER
- Date :
- Version / commit :
- Pays / appareil / navigateur :
- Étapes de reproduction :
- Résultat attendu :
- Résultat observé :
- Preuves :
- Impact :
- Cause probable :
- Correctif proposé :
- Test de non-régression :
