# Idée — Titre

- Statut : PROPOSÉ
- Problème ciblé :
- Public concerné :
- Solution :
- Bénéfice utilisateur :
- Coût estimé :
- Difficulté :
- Risques :
- Méthode de test :
- Indicateurs de réussite :
- Décision :
