# Compte rendu — AAAA-MM-JJ

## Sujet
## Périmètre et versions examinées
## Sources consultées
## Constats vérifiés
## Hypothèses / éléments à confirmer
## Décisions explicites
## Actions effectuées
## Actions non effectuées
## Blocages
## Prochaines étapes
