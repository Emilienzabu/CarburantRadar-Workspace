# Idées et améliorations

## À étudier
- afficher la date/heure de mise à jour pour chaque prix ;
- distinguer clairement données réelles, estimations et données indisponibles ;
- calculer les économies nettes après détour ;
- améliorer les démonstrations vidéo de l'application ;
- rendre les pages locales réellement utiles et non répétitives ;
- améliorer les mécanismes de partage et de retour utilisateur.

## Règle
Une idée reste `PROPOSÉE` tant qu'elle n'est pas explicitement acceptée.
