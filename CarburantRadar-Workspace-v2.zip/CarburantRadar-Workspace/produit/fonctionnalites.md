# Fonctionnalités

## Fonctionnalités décrites historiquement
- géolocalisation ;
- recherche dans plusieurs rayons (5, 10, 20, 50 km) ;
- filtres par carburant ;
- liste et statistiques de stations ;
- favoris et noms personnalisés ;
- repères Domicile et Travail ;
- alertes de prix et notifications ;
- mode itinéraire ;
- réglages véhicule et estimation de coût ;
- cartes et navigation externe ;
- compte et synchronisation partielle.

Cette liste doit être vérifiée contre l'application actuelle avant d'être présentée comme exhaustive.
