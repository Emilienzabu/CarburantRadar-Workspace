# Données et sources

## France
Source connue : data.economie.gouv.fr.

## Espagne et Italie
Des pages et mappings de carburants existent selon les informations fournies, mais les sources exactes et leurs conditions d'utilisation doivent être documentées.

## À enregistrer pour chaque source
- URL et organisme ;
- pays et couverture ;
- fréquence de mise à jour ;
- champs et unités ;
- licence et conditions d'utilisation ;
- limites, erreurs et dates de collecte.
