# CarburantRadar-Workspace

Espace documentaire privé destiné à centraliser le contexte, les décisions, les audits, les idées et les éléments techniques du projet CarburantRadar.

## Démarrage d'une session
Lire dans cet ordre :
1. `CONTEXTE_GLOBAL.md`
2. `AVANCEMENT.md`
3. `DECISIONS.md`
4. `REGLES_DE_TRAVAIL.md`
5. `SECURITE_ET_SECRETS.md`

Puis consulter les dossiers `codes/`, `audits/`, `strategie/`, `produit/` et `journal/` selon le sujet.

## Règle essentielle
Ce dépôt est documentaire. Il est distinct du dépôt de production CarburantRadar. Aucune modification, publication, exécution de workflow ou dépense ne doit être effectuée sans demande explicite.

## Fiabilité des informations
Chaque information doit être distinguée selon son statut : `VÉRIFIÉ`, `À CONFIRMER`, `HYPOTHÈSE`, `PROPOSÉ`, `ACCEPTÉ`, `EN COURS`, `TERMINÉ` ou `BLOQUÉ`.
