# Journal des sessions

Créer un fichier daté par session. Indiquer le sujet, les sources examinées, les constats nouveaux, les décisions réellement prises et les prochaines étapes. Ne pas y copier de secrets.
