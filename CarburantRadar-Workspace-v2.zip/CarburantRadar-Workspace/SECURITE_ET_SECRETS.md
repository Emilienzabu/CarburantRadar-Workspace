# Sécurité et secrets

## Interdictions
Ne jamais déposer dans ce dépôt :
- mots de passe ;
- tokens OAuth ou refresh tokens ;
- clés API privées ;
- secrets Cloudflare ;
- clés privées, cookies ou codes de récupération ;
- coordonnées GPS précises ou données personnelles d'utilisateurs.

## Procédure de partage du code
Avant de copier un Worker ou un fichier de configuration, retirer les valeurs secrètes. Conserver les noms de variables d'environnement si cela aide à comprendre le code, mais remplacer leurs valeurs par `[REDACTED]`.

## Accès
- Dépôt privé recommandé.
- Accorder uniquement les accès nécessaires.
- Vérifier les applications OAuth autorisées.
- Ne pas confondre accès au dépôt documentaire et accès au dépôt de production.

## Audit
Vérifier notamment l'authentification, les autorisations, le stockage des tokens, la limitation de débit, la validation des entrées, la conservation et la suppression des données.
